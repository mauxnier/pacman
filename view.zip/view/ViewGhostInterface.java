package view;

public interface ViewGhostInterface {

}