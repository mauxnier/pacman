package view;

public interface ViewGameInterface {

}