package view;

public interface ViewGridInterface {

}