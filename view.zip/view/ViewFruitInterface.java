package view;

public interface ViewFruitInterface {

}