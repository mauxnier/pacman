package view;

public interface ViewPacmanInterface {

}