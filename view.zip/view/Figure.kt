package view

public abstract class Figure
